const scene = new THREE.Scene();
scene.background = new THREE.Color(0x111111);

const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer();
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

// Player
const playerGeometry = new THREE.BoxGeometry(1, 1, 1);
const playerMaterial = new THREE.MeshBasicMaterial({ color: 0x00ffff });
const player = new THREE.Mesh(playerGeometry, playerMaterial);
scene.add(player);

// Ground
const groundGeometry = new THREE.PlaneGeometry(100, 100);
const groundMaterial = new THREE.MeshBasicMaterial({ color: 0x333333, side: THREE.DoubleSide });
const ground = new THREE.Mesh(groundGeometry, groundMaterial);
ground.rotation.x = Math.PI / 2;
scene.add(ground);

// Camera setup
camera.position.z = 5;
camera.position.y = 5;
camera.lookAt(player.position);

// Resize
window.addEventListener("resize", () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

// Controls
const keys = {};
window.addEventListener("keydown", (e) => keys[e.key.toLowerCase()] = true);
window.addEventListener("keyup", (e) => keys[e.key.toLowerCase()] = false);

// Bullets
const bullets = [];
window.addEventListener("click", () => {
  const bulletGeometry = new THREE.SphereGeometry(0.2, 8, 8);
  const bulletMaterial = new THREE.MeshBasicMaterial({ color: 0xff0000 });
  const bullet = new THREE.Mesh(bulletGeometry, bulletMaterial);
  bullet.position.copy(player.position);
  bullet.direction = new THREE.Vector3(0, 0, -1).applyQuaternion(player.quaternion);
  bullets.push(bullet);
  scene.add(bullet);
});

// Enemies
const enemies = [];
function spawnEnemy() {
  const enemyGeometry = new THREE.BoxGeometry(1, 1, 1);
  const enemyMaterial = new THREE.MeshBasicMaterial({ color: 0xff00ff });
  const enemy = new THREE.Mesh(enemyGeometry, enemyMaterial);
  enemy.position.set((Math.random() - 0.5) * 50, 0.5, (Math.random() - 0.5) * 50);
  enemies.push(enemy);
  scene.add(enemy);
}
setInterval(spawnEnemy, 2000); // spawn every 2 seconds

function animate() {
  requestAnimationFrame(animate);

  // Movement
  const speed = 0.1;
  if (keys["w"]) player.position.z -= speed;
  if (keys["s"]) player.position.z += speed;
  if (keys["a"]) player.position.x -= speed;
  if (keys["d"]) player.position.x += speed;

  // Move bullets
  bullets.forEach((b, i) => {
    b.position.add(b.direction.clone().multiplyScalar(0.5));
    if (b.position.length() > 100) {
      scene.remove(b);
      bullets.splice(i, 1);
    }
  });

  // Move enemies and check collisions
  enemies.forEach((enemy, ei) => {
    const direction = player.position.clone().sub(enemy.position).normalize();
    enemy.position.add(direction.multiplyScalar(0.02));

    bullets.forEach((bullet, bi) => {
      if (enemy.position.distanceTo(bullet.position) < 1) {
        scene.remove(enemy);
        scene.remove(bullet);
        enemies.splice(ei, 1);
        bullets.splice(bi, 1);
      }
    });
  });

  // Camera follows player
  camera.position.x = player.position.x;
  camera.position.z = player.position.z + 5;
  camera.lookAt(player.position);

  renderer.render(scene, camera);
}
animate();
